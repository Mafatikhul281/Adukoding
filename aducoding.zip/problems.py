problems = [
    {
        "question": "Buat variabel bernama 'jawaban' dengan nilai 10 * 2",
        "answer": "20"
    },
    {
        "question": "Buat variabel 'jawaban' yang berisi jumlah dari 1 sampai 5",
        "answer": "15"
    },
    {
        "question": "Isi variabel 'jawaban' dengan panjang string 'halo dunia'",
        "answer": "10"
    },
    {
        "question": "Buat list [1,2,3] dan isi 'jawaban' dengan jumlahnya",
        "answer": "6"
    },
    {
        "question": "Isi 'jawaban' dengan hasil 2 pangkat 5",
        "answer": "32"
    }
]